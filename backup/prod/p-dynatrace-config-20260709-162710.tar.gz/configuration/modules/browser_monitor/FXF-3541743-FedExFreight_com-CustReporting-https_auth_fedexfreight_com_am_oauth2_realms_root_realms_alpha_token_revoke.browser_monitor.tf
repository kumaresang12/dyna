resource "dynatrace_browser_monitor" "FXF-3541743-FedExFreight_com-CustReporting-https_auth_fedexfreight_com_am_oauth2_realms_root_realms_alpha_token_revoke" {
  name                   = "FXF-3541743-FedExFreight_com-CustReporting - https://auth.fedexfreight.com/am/oauth2/realms/root/realms/alpha/token/revoke"
  enabled                = true
  frequency              = 15
  locations              = [ "GEOLOCATION-9999453BE4BDB3CD", "GEOLOCATION-5B3CDE358F4D4B31", "GEOLOCATION-3E5C618F168F83BD" ]
  manually_assigned_apps = [ "APPLICATION-0C1D4F1641C7EDC9" ]
  anomaly_detection {
    loading_time_thresholds {
      # enabled = false
    }
    outage_handling {
      global_outage  = true
      # local_outage = false
      retry_on_error = true
      global_outage_policy {
        consecutive_runs = 1
      }
    }
  }
  key_performance_metrics {
    load_action_kpm = "VISUALLY_COMPLETE"
    xhr_action_kpm  = "VISUALLY_COMPLETE"
  }
  script {
    type = "clickpath"
    configuration {
      # bypass_csp           = false
      # disable_web_security = false
      # monitor_frames       = true
      device {
        name        = "Desktop"
        orientation = "landscape"
      }
    }
    events {
      event {
        description = "https://auth.fedexfreight.com/am/oauth2/realms/root/realms/alpha/token/revoke"
        navigate {
          url = "https://www.fedexfreight.com/ecap/report?activeRoute=createSinglePage&reportTypeRoute=submitted"
          wait {
            wait_for = "page_complete"
          }
        }
      }
    }
  }
  tags {
    tag {
      context = "CONTEXTLESS"
      key     = "Freight.com"
      source  = "USER"
    }
    tag {
      context = "CONTEXTLESS"
      key     = "EAI"
      source  = "USER"
      value   = "3541743"
    }
  }
}
