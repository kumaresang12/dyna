resource "dynatrace_browser_monitor" "FXF-3541742-FedExFreight_com-Tracking-loading_of_page_wtrk_fedextracking" {
  name                   = "FXF-3541742-FedExFreight_com-Tracking - loading of page /wtrk/fedextracking/"
  enabled                = true
  frequency              = 15
  locations              = [ "GEOLOCATION-9999453BE4BDB3CD", "GEOLOCATION-5B3CDE358F4D4B31", "GEOLOCATION-3E5C618F168F83BD" ]
  manually_assigned_apps = [ "APPLICATION-96B19E7A98FE5A7E" ]
  anomaly_detection {
    loading_time_thresholds {
      # enabled = false
    }
    outage_handling {
      global_outage  = true
      # local_outage = false
      retry_on_error = true
      global_outage_policy {
        consecutive_runs = 1
      }
    }
  }
  key_performance_metrics {
    load_action_kpm = "VISUALLY_COMPLETE"
    xhr_action_kpm  = "VISUALLY_COMPLETE"
  }
  script {
    type = "clickpath"
    configuration {
      # bypass_csp           = false
      # disable_web_security = false
      # monitor_frames       = true
      device {
        name        = "Desktop"
        orientation = "landscape"
      }
    }
    events {
      event {
        description = "loading of page /wtrk/fedextracking/"
        navigate {
          url = "https://www.fedexfreight.com/wtrk/fedextracking/"
          wait {
            wait_for = "page_complete"
          }
        }
      }
    }
  }
  tags {
    tag {
      context = "CONTEXTLESS"
      key     = "EAI"
      source  = "USER"
      value   = "3541742"
    }
    tag {
      context = "CONTEXTLESS"
      key     = "Freight.com"
      source  = "USER"
    }
  }
}
