resource "dynatrace_alerting" "faie-3537805_alerting" {
  name = "faie-3537805 alerting"
  rules {
    rule {
      delay_in_minutes = 0
      include_mode     = "INCLUDE_ALL"
      severity_level   = "AVAILABILITY"
      tags             = [ "pcf.organization_name:3537805" ]
    }
    rule {
      delay_in_minutes = 0
      include_mode     = "INCLUDE_ALL"
      severity_level   = "CUSTOM_ALERT"
      tags             = [ "pcf.organization_name:3537805" ]
    }
    rule {
      delay_in_minutes = 0
      include_mode     = "INCLUDE_ALL"
      severity_level   = "ERRORS"
      tags             = [ "pcf.organization_name:3537805" ]
    }
    rule {
      delay_in_minutes = 0
      include_mode     = "INCLUDE_ALL"
      severity_level   = "MONITORING_UNAVAILABLE"
      tags             = [ "pcf.organization_name:3537805" ]
    }
    rule {
      delay_in_minutes = 30
      include_mode     = "INCLUDE_ALL"
      severity_level   = "PERFORMANCE"
      tags             = [ "pcf.organization_name:3537805" ]
    }
    rule {
      delay_in_minutes = 30
      include_mode     = "INCLUDE_ALL"
      severity_level   = "RESOURCE_CONTENTION"
      tags             = [ "pcf.organization_name:3537805" ]
    }
  }
}
