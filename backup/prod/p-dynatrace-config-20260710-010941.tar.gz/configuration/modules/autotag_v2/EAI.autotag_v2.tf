resource "dynatrace_autotag_v2" "EAI" {
  name                          = "EAI"
  description                   = "EAI"
  # rules_maintained_externally = false
  rules {
    rule {
      type                = "ME"
      enabled             = true
      value_format        = "{Host:Environment:fdxfct_eai}"
      value_normalization = "Leave text as-is"
      attribute_rule {
        entity_type               = "PROCESS_GROUP"
        pg_to_host_propagation    = true
        pg_to_service_propagation = true
        conditions {
          condition {
            dynamic_key        = "fdxfct_eai"
            dynamic_key_source = "ENVIRONMENT"
            key                = "HOST_CUSTOM_METADATA"
            operator           = "EXISTS"
          }
        }
      }
    }
  }
}
