resource "dynatrace_api_detection" "Built-In_NET_Azure_Service_Fabric" {
  api_color       = "#fff29a"
  api_name        = "Built-In .NET Azure Service Fabric"
  insert_after    = "vu9U3hXa3q0AAAABABxidWlsdGluOmFwaXMuZGV0ZWN0aW9uLXJ1bGVzAAZ0ZW5hbnQABnRlbmFudAAkZjY1NTMwZTQtZDQxNi0zYmU2LTg4ZDMtMjI2ZTNjZTA0Mjcyvu9U3hXa3q0"
  technology      = "dotNet"
  third_party_api = true
  conditions {
    condition {
      base    = "FQCN"
      matcher = "BEGINS_WITH"
      pattern = "Microsoft.ServiceFabric."
    }
  }
}
