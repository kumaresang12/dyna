resource "dynatrace_api_detection" "Built-In_Java_MongoDB" {
  api_color       = "#fff29a"
  api_name        = "Built-In Java MongoDB"
  insert_after    = "vu9U3hXa3q0AAAABABxidWlsdGluOmFwaXMuZGV0ZWN0aW9uLXJ1bGVzAAZ0ZW5hbnQABnRlbmFudAAkMjkzOTlmMzQtNjEwYS0zMjM5LTllY2ItZTc0MWE0NzFlZDQ3vu9U3hXa3q0"
  technology      = "Java"
  third_party_api = true
  conditions {
    condition {
      base    = "FQCN"
      matcher = "BEGINS_WITH"
      pattern = "com.mongodb."
    }
    condition {
      base    = "FQCN"
      matcher = "BEGINS_WITH"
      pattern = "com.novus.casbah.mongodb."
    }
    condition {
      base    = "FQCN"
      matcher = "BEGINS_WITH"
      pattern = "org.bson."
    }
  }
}
