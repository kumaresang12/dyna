resource "dynatrace_application_detection_rule" "APPLICATION-274E3AF3126B2242_URL_CONTAINS_fedexfreight_com_profile" {
  application_identifier = "APPLICATION-274E3AF3126B2242"
  filter_config {
    application_match_target = "URL"
    application_match_type   = "CONTAINS"
    pattern                  = "fedexfreight.com/profile"
  }
}
