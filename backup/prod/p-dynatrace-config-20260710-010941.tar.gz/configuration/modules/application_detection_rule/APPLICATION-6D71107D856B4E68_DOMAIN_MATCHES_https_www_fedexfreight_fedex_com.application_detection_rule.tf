resource "dynatrace_application_detection_rule" "APPLICATION-6D71107D856B4E68_DOMAIN_MATCHES_https_www_fedexfreight_fedex_com" {
  application_identifier = "APPLICATION-6D71107D856B4E68"
  filter_config {
    application_match_target = "DOMAIN"
    application_match_type   = "MATCHES"
    pattern                  = "https://www.fedexfreight.fedex.com/"
  }
}
