resource "dynatrace_application_detection_rule" "APPLICATION-103C4DEC0EF04CD8_URL_CONTAINS_fedexfreight_com_register" {
  application_identifier = "APPLICATION-103C4DEC0EF04CD8"
  filter_config {
    application_match_target = "URL"
    application_match_type   = "CONTAINS"
    pattern                  = "fedexfreight.com/register/"
  }
}
