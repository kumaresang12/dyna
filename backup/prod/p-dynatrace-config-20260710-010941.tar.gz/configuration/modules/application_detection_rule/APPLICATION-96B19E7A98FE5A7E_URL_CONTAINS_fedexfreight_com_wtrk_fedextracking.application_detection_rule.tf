resource "dynatrace_application_detection_rule" "APPLICATION-96B19E7A98FE5A7E_URL_CONTAINS_fedexfreight_com_wtrk_fedextracking" {
  application_identifier = "APPLICATION-96B19E7A98FE5A7E"
  filter_config {
    application_match_target = "URL"
    application_match_type   = "CONTAINS"
    pattern                  = "fedexfreight.com/wtrk/fedextracking/"
  }
}
