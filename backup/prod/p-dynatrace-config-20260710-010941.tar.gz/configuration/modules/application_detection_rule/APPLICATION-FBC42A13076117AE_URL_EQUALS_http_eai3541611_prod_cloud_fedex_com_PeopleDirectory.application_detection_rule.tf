resource "dynatrace_application_detection_rule" "APPLICATION-FBC42A13076117AE_URL_EQUALS_http_eai3541611_prod_cloud_fedex_com_PeopleDirectory" {
  application_identifier = "APPLICATION-FBC42A13076117AE"
  filter_config {
    application_match_target = "URL"
    application_match_type   = "EQUALS"
    pattern                  = "http://eai3541611.prod.cloud.fedex.com/PeopleDirectory"
  }
}
