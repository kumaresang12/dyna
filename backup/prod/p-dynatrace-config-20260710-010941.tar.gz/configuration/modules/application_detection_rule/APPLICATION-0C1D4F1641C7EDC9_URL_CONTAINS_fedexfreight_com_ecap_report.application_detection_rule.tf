resource "dynatrace_application_detection_rule" "APPLICATION-0C1D4F1641C7EDC9_URL_CONTAINS_fedexfreight_com_ecap_report" {
  application_identifier = "APPLICATION-0C1D4F1641C7EDC9"
  filter_config {
    application_match_target = "URL"
    application_match_type   = "CONTAINS"
    pattern                  = "fedexfreight.com/ecap/report"
  }
}
