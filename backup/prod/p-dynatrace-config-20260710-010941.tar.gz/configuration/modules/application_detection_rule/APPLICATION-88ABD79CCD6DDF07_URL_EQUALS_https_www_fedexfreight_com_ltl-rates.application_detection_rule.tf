resource "dynatrace_application_detection_rule" "APPLICATION-88ABD79CCD6DDF07_URL_EQUALS_https_www_fedexfreight_com_ltl-rates" {
  application_identifier = "APPLICATION-88ABD79CCD6DDF07"
  filter_config {
    application_match_target = "URL"
    application_match_type   = "EQUALS"
    pattern                  = "https://www.fedexfreight.com/ltl-rates/"
  }
}
