resource "dynatrace_activegate_updates" "ENVIRONMENT_ACTIVE_GATE-000000004976D7BD" {
  auto_update = false
  scope       = "ENVIRONMENT_ACTIVE_GATE-000000004976D7BD"
}
