resource "dynatrace_activegate_updates" "ENVIRONMENT_ACTIVE_GATE-0000000021CAEE96" {
  auto_update = false
  scope       = "ENVIRONMENT_ACTIVE_GATE-0000000021CAEE96"
}
