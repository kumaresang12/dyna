resource "dynatrace_activegate_updates" "ENVIRONMENT_ACTIVE_GATE-00000000083BC220" {
  auto_update = false
  scope       = "ENVIRONMENT_ACTIVE_GATE-00000000083BC220"
}
