resource "dynatrace_activegate_updates" "ENVIRONMENT_ACTIVE_GATE-0000000076AA7469" {
  auto_update = false
  scope       = "ENVIRONMENT_ACTIVE_GATE-0000000076AA7469"
}
