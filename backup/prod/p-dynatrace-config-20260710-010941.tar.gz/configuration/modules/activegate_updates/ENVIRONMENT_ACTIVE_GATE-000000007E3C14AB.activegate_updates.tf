resource "dynatrace_activegate_updates" "ENVIRONMENT_ACTIVE_GATE-000000007E3C14AB" {
  auto_update = false
  scope       = "ENVIRONMENT_ACTIVE_GATE-000000007E3C14AB"
}
