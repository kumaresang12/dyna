resource "dynatrace_activegate_updates" "ENVIRONMENT_ACTIVE_GATE-000000000A11D365" {
  auto_update = false
  scope       = "ENVIRONMENT_ACTIVE_GATE-000000000A11D365"
}
