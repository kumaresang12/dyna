resource "dynatrace_activegate_updates" "ENVIRONMENT_ACTIVE_GATE-000000003539F55E" {
  auto_update = false
  scope       = "ENVIRONMENT_ACTIVE_GATE-000000003539F55E"
}
