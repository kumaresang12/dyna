resource "dynatrace_activegate_updates" "ENVIRONMENT_ACTIVE_GATE-0000000035960DA3" {
  auto_update = false
  scope       = "ENVIRONMENT_ACTIVE_GATE-0000000035960DA3"
}
