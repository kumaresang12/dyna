resource "dynatrace_activegate_updates" "ENVIRONMENT_ACTIVE_GATE-0000000078EF4088" {
  auto_update = false
  scope       = "ENVIRONMENT_ACTIVE_GATE-0000000078EF4088"
}
