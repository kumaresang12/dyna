resource "dynatrace_activegate_updates" "ENVIRONMENT_ACTIVE_GATE-000000007CD30BAE" {
  auto_update = false
  scope       = "ENVIRONMENT_ACTIVE_GATE-000000007CD30BAE"
}
