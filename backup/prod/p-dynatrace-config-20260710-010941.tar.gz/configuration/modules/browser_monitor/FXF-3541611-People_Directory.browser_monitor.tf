resource "dynatrace_browser_monitor" "FXF-3541611-People_Directory" {
  name                   = "FXF-3541611-People Directory"
  enabled                = true
  frequency              = 15
  locations              = [ "SYNTHETIC_LOCATION-B08CD00B6F2C799D", "SYNTHETIC_LOCATION-13DB608B6CB1513D", "SYNTHETIC_LOCATION-ABBFEA0E55BC85D3" ]
  manually_assigned_apps = [ "APPLICATION-FBC42A13076117AE" ]
  anomaly_detection {
    loading_time_thresholds {
      # enabled = false
    }
    outage_handling {
      global_outage  = true
      # local_outage = false
      retry_on_error = true
      global_outage_policy {
        consecutive_runs = 1
      }
    }
  }
  key_performance_metrics {
    load_action_kpm = "VISUALLY_COMPLETE"
    xhr_action_kpm  = "VISUALLY_COMPLETE"
  }
  script {
    type = "clickpath"
    configuration {
      # bypass_csp           = false
      # disable_web_security = false
      # monitor_frames       = true
      device {
        name        = "Desktop"
        orientation = "landscape"
      }
    }
    events {
      event {
        description = "loading of page /peopledirectory"
        navigate {
          url = "http://eai3541611.prod.cloud.fedex.com/PeopleDirectory"
          wait {
            wait_for = "page_complete"
          }
        }
      }
    }
  }
  tags {
    tag {
      context = "CONTEXTLESS"
      key     = "EAI"
      source  = "USER"
      value   = "3541611"
    }
  }
}
