resource "dynatrace_browser_monitor" "FXF-3541738-FedExFreight_com-LogIn-loading_of_page_login" {
  name      = "FXF-3541738-FedExFreight_com-LogIn - loading of page /login/"
  enabled   = true
  frequency = 15
  locations = [ "GEOLOCATION-9999453BE4BDB3CD", "GEOLOCATION-5B3CDE358F4D4B31", "GEOLOCATION-3E5C618F168F83BD" ]
  anomaly_detection {
    loading_time_thresholds {
      # enabled = false
    }
    outage_handling {
      global_outage  = true
      # local_outage = false
      retry_on_error = true
      global_outage_policy {
        consecutive_runs = 1
      }
    }
  }
  key_performance_metrics {
    load_action_kpm = "VISUALLY_COMPLETE"
    xhr_action_kpm  = "VISUALLY_COMPLETE"
  }
  script {
    type = "availability"
    configuration {
      # bypass_csp           = false
      # disable_web_security = false
      monitor_frames         = false
      device {
        name        = "Desktop"
        orientation = "landscape"
      }
    }
    events {
      event {
        description = "Loading of \"https://www.fedexfreight.com/login/\""
        navigate {
          url = "https://www.fedexfreight.com/login/"
          wait {
            wait_for = "page_complete"
          }
        }
      }
    }
  }
  tags {
    tag {
      context = "CONTEXTLESS"
      key     = "Freight.com"
      source  = "USER"
    }
  }
}
