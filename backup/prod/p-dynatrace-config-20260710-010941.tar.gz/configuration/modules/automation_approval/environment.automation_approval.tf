resource "dynatrace_automation_approval" "environment" {
  # external_approvals_enabled         = false
  workflow_app_access_approval_enabled = false
}
